
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.ianzb.zbcraft.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.ianzb.zbcraft.block.ZbKuaiBlock;
import net.ianzb.zbcraft.ZbMod;

public class ZbModBlocks {
	public static Block BLOCK_OF_ZB;

	public static void load() {
		BLOCK_OF_ZB = Registry.register(Registry.BLOCK, new ResourceLocation(ZbMod.MODID, "block_of_zb"), new ZbKuaiBlock());
	}

	public static void clientLoad() {
		ZbKuaiBlock.clientInit();
	}
}
