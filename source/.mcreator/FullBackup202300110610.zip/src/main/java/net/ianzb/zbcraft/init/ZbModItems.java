
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.ianzb.zbcraft.init;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.ianzb.zbcraft.item.ZbItem;
import net.ianzb.zbcraft.ZbMod;

public class ZbModItems {
	public static Item ITEM_OF_ZB;
	public static Item BLOCK_OF_ZB;

	public static void load() {
		ITEM_OF_ZB = Registry.register(Registry.ITEM, new ResourceLocation(ZbMod.MODID, "item_of_zb"), new ZbItem());
		BLOCK_OF_ZB = Registry.register(Registry.ITEM, new ResourceLocation(ZbMod.MODID, "block_of_zb"), new BlockItem(ZbModBlocks.BLOCK_OF_ZB, new Item.Properties().tab(ZbModTabs.TAB_TAB_OF_ZB)));
	}
}
