
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.ianzb.zbcraft.init;

import net.minecraft.world.entity.decoration.PaintingVariant;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.ianzb.zbcraft.ZbMod;

public class ZbModPaintings {
	public static void load() {
		Registry.register(Registry.PAINTING_VARIANT, new ResourceLocation(ZbMod.MODID, "zbpaintbig"), new PaintingVariant(32, 32));
		Registry.register(Registry.PAINTING_VARIANT, new ResourceLocation(ZbMod.MODID, "paint_of_zb"), new PaintingVariant(16, 16));
	}
}
